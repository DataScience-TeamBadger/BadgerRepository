# BadgerRepository
This is our team Repository

Contributors:
Michael von der Lippe
Steven Proctor
John DeMey
Alex Kerzner
Deonarine Sahdeo